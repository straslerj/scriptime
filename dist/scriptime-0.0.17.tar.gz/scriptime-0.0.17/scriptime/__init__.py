from .main import Timer

__all__ = ["Timer"]
