# scriptime
Python library to notify when a script has finished running and providing insights such as run time, CPU and RAM usage, and more.
