from .main import YourClass

__all__ = ["YourClass"]
